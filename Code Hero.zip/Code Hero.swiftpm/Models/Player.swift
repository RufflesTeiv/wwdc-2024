//
//  Player.swift
//
//
//  Created by Rafa (Ruffles) on 20/02/24.
//

import Foundation

class Player {
    var maxHealth : Int = 5
}
